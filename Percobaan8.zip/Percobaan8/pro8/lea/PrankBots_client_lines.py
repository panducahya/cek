restarting...
pointer...
server into vps
wait/"linux","cantos","windows","PrankBots","vultra"/import PRANKBOTS or PB expel thrift=11 into file microscofe.txt for database
prank import wait poin.services
prank import database.server
from..prank, ranger, response, thrift, ttyps, rangerv2, PrankBots_v.04
import updater from ttyps..thrift..line
from LINE.DEVELOVER import PRANKBOTS
imposible UTF.8 UIX to PYTHON3

##INI JANGAN DI HAPUS DAN JANGAN DI OTAK ATIK##
#PRANKBOTS CREATOR
#Acil
